# 💛 Flores Amarillas para Mi Princesa 💛

Este proyecto está hecho con todo mi amor para la **mejor novia del universo M.F.T.Z** ✨🌼  
Un pequeño detalle digital lleno de 🌻 flores, ✨ brillos y nuestras fotos 💖.  

## 💖 Sorpresa
Al abrir la página verás:
- 🌼 Un slideshow infinito de nuestras fotos con efecto **fade**.
- ✨ Brillitos mágicos cayendo como lluvia.
- 🌻 Flores amarillas que simbolizan nuestro amor.
- 🎶 Un botoncito con nuestra canción especial: *Flores Amarillas*.  

## 🌟 Mensaje
> *“La mejor novia del universo M.F.T.Z — Mi princesa emosha 😍😍”*  

---

✨ Hecho con amor por [avilaernestito](https://github.com/avilaernestito) 💛
